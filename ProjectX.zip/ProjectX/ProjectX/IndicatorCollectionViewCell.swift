//
//  IndicatorCollectionViewCell.swift
//  ProjectX
//
//  Created by Junaid Umer on 3/13/19.
//  Copyright © 2019 Junaid Umer. All rights reserved.
//

import UIKit

class IndicatorCollectionViewCell: UICollectionViewCell {
    
    
}
