//
//  ViewController.swift
//  ProjectX
//
//  Created by Junaid Umer on 3/13/19.
//  Copyright © 2019 Junaid Umer. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var valueLabel: UILabel!
    var startHour = 0
    var currentDate = Date()
    var selectedItem = 0 {
        didSet{
            collectionView.selectItem(at: IndexPath(item: selectedItem, section: 0), animated: true, scrollPosition: .centeredHorizontally)
            
            let totalMinsScrolled = selectedItem * 15
            let hours = Double(totalMinsScrolled)/60.0
            let remainder1 = hours.truncatingRemainder(dividingBy: 1)
            let mins = remainder1 * 60
            
            valueLabel.text = "\(startHour + Int(hours)):\(Int(mins))"
 
        }
    }
    var totalNumberOfCells = 0 {
        didSet{
        collectionView.reloadData()
        }
    }
    
    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        calculateTime()
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        collectionView.isScrollEnabled = true
        let width = collectionView.frame.width/2
        collectionView.contentInset = UIEdgeInsets(top: 0, left: width, bottom: 0, right: width)
    }
    
    func calculateTime() {
        let date = Date()
        let calendar = Calendar.current
        var hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        if minutes > 0 {
            hour += 1
        }
        startHour = hour
        hour += 12
        let mins = hour * 60
        totalNumberOfCells = mins/15
        valueLabel.text = "\(startHour):00"
    }
    
    func calculateScrollIndex(scrollView: UIScrollView) {
        let offSetX = scrollView.contentOffset.x + self.view.bounds.size.width / 2 - 12
        // offset is the value which scroll view did scroll
        //and 12 is the spacing between cell we divided it to get exact cell location
        let value = Int((offSetX/12).rounded())
        collectionView.scrollToItem(at: IndexPath(item: value, section: 0), at: .centeredHorizontally, animated: true)
        selectedItem = value
    }
}


extension ViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return totalNumberOfCells
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var cell: IndicatorCollectionViewCell?
        if(indexPath.row % 4 == 0) {
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "large", for: indexPath) as? IndicatorCollectionViewCell
            
        }else{
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "small", for: indexPath) as? IndicatorCollectionViewCell
        }
        return cell ?? UICollectionViewCell()
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    }
   
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        calculateScrollIndex(scrollView: scrollView)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        calculateScrollIndex(scrollView: scrollView)
    }
}
